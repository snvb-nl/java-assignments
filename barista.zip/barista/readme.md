barista-matic console application
