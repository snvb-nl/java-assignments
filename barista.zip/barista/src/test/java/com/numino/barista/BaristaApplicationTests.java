package com.numino.barista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaristaApplicationTests {

	@Test
	void contextLoads() {
	}

}
